import App from "./pages/app.js";
import { pushManager } from "./utils/push-manager.js";
import { navigation } from "./components/navigation.js";
import L from "leaflet";

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "/po1/leaflet-images/marker-icon-2x.png",
  iconUrl: "/po1/leaflet-images/marker-icon.png",
  shadowUrl: "/po1/leaflet-images/marker-shadow.png",
});

console.log("🚀 Memulai Cerita di Sekitarmu...");

const app = new App({
  drawerButton: document.querySelector("#drawer-button"),
  navigationDrawer: document.querySelector("#navigation-drawer"),
  content: document.querySelector("#main-content"),
});

let appInitialized = false;

window.addEventListener("hashchange", () => app.renderPage());
window.addEventListener("load", async () => {
  if (appInitialized) {
    console.log("⚠️ App already initialized, skipping...");
    return;
  }
  appInitialized = true;

  await app.renderPage();
  console.log("✅ Aplikasi berhasil dimulai");

  await initializePushNotifications();

  initializeServiceWorker();
});

async function initializePushNotifications() {
  try {
    console.log("📱 Initializing push notifications...");

    const pushSupported = await pushManager.init();

    if (pushSupported) {
      await navigation.init();
      console.log("✅ Push notifications initialized successfully");
    } else {
      console.log("📱 Push notifications not supported");
    }
  } catch (error) {
    console.error("❌ Push notifications initialization failed:", error);
  }
}
// Service Worker initialization - FIXED
function initializeServiceWorker() {
  // 🚫 NONAKTIFKAN di development - PASTI
  if (
    window.location.hostname === "localhost" ||
    window.location.hostname === "127.0.0.1" ||
    window.location.hostname === "0.0.0.0"
  ) {
    console.log("💻 Development: Service Worker dinonaktifkan");
    return;
  }

  // Hanya di production
  if ("serviceWorker" in navigator) {
    const swUrl = "/po1/sw.js";
    console.log("🌐 Registering Service Worker for production...");

    navigator.serviceWorker
      .register(swUrl, {
        scope: "/po1/",
      })
      .then((registration) => {
        console.log("✅ Service Worker terdaftar:", registration.scope);
      })
      .catch((error) => {
        console.log("ℹ️ Service Worker tidak tersedia:", error.message);
      });
  }
}

let deferredPrompt;
window.addEventListener("beforeinstallprompt", (e) => {
  console.log("📱 Install prompt tersedia");
  e.preventDefault();
  deferredPrompt = e;
});

window.app = app;
