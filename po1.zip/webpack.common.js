const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");

module.exports = {
  entry: "./src/scripts/index.js",
  output: {
    path: path.resolve(__dirname, "dist"),
    filename: "main.bundle.js",
    clean: true,
    publicPath: "/po1/",
  },
  module: {
    rules: [
      {
        test: /\.(png|svg|jpg|jpeg|gif)$/i,
        type: "asset/resource",
      },
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: "./src/index.html",
      filename: "index.html",
    }),
    new CopyWebpackPlugin({
      patterns: [
        {
          from: "./src/public",
          to: ".",
          noErrorOnMissing: true,
        },
        {
          from: "./src/styles/styles.css", // CSS dari src/styles
          to: "styles.css",
        },
        {
          from: "./app.webmanifest",
          to: ".",
        },
        {
          from: "./sw.js",
          to: ".",
        },
      ],
    }),
  ],
};
