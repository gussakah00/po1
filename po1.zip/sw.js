const CACHE_NAME = "cerita-app-v3";

const STATIC_ASSETS = [
  "/po1/",
  "/po1/index.html",
  "/po1/styles.css",
  "/po1/main.bundle.js",
  "/po1/icons/icon-192x192.png",
  "/po1/icons/icon-512x512.png",
];

self.addEventListener("install", (event) => {
  console.log("🔧 Service Worker: Installing...");

  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => {
        console.log("💾 Opening cache...");
        return cache
          .addAll(STATIC_ASSETS)
          .then(() => console.log("✅ Static assets cached"))
          .catch((error) => {
            console.log("⚠️ Some assets failed to cache:", error);
            return Promise.resolve();
          });
      })
      .then(() => {
        console.log("✅ Installation complete");
        return self.skipWaiting();
      })
      .catch((error) => {
        console.log("❌ Installation error, but skipping wait:", error);
        return self.skipWaiting();
      })
  );
});

self.addEventListener("activate", (event) => {
  console.log("🔧 Service Worker: Activating...");

  event.waitUntil(
    Promise.all([
      caches.keys().then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== CACHE_NAME) {
              console.log("🗑️ Deleting old cache:", cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      }),
      self.clients.claim(),
    ])
      .then(() => {
        console.log("✅ Activation complete");
      })
      .catch((error) => {
        console.log("⚠️ Activation error, but continuing:", error);
        return self.clients.claim();
      })
  );
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") {
    return;
  }

  const url = new URL(event.request.url);

  if (!url.origin.startsWith(self.location.origin)) {
    return;
  }

  if (
    url.pathname.includes("/api/") ||
    url.href.includes("story-api.dicoding.dev")
  ) {
    return;
  }

  if (event.request.mode === "navigate") {
    event.respondWith(
      caches
        .match("/po1/index.html")
        .then((cachedResponse) => {
          if (cachedResponse) {
            console.log("📄 Serving cached index.html for navigation");
            return cachedResponse;
          }
          console.log("🌐 Fetching fresh page for navigation");
          return fetch(event.request);
        })
        .catch((error) => {
          console.log("❌ Navigation failed, returning offline page");

          return new Response(
            `
            <!DOCTYPE html>
            <html>
              <head>
                <title>Offline - Cerita di Sekitarmu</title>
                <style>
                  body { font-family: Arial, sans-serif; padding: 20px; text-align: center; }
                  h1 { color: #4f46e5; }
                </style>
              </head>
              <body>
                <h1>📱 Cerita di Sekitarmu</h1>
                <p>Anda sedang offline. Aplikasi akan tersedia ketika koneksi internet kembali.</p>
              </body>
            </html>
          `,
            {
              status: 200,
              headers: { "Content-Type": "text/html" },
            }
          );
        })
    );
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        if (response.status === 200) {
          const responseClone = response.clone();
          caches
            .open(CACHE_NAME)
            .then((cache) => {
              cache
                .put(event.request, responseClone)
                .then(() => console.log("💾 Cached:", event.request.url))
                .catch((cacheError) =>
                  console.log("⚠️ Cache put failed:", cacheError)
                );
            })
            .catch((cacheError) => {
              console.log("⚠️ Cache open failed:", cacheError);
            });
        }
        return response;
      })
      .catch((fetchError) => {
        console.log("🌐 Network failed, trying cache:", event.request.url);

        return caches.match(event.request).then((cachedResponse) => {
          if (cachedResponse) {
            console.log("💾 Serving from cache:", event.request.url);
            return cachedResponse;
          }
          console.log("❌ Not in cache either:", event.request.url);
          return new Response("Resource not available", {
            status: 408,
            headers: { "Content-Type": "text/plain" },
          });
        });
      })
  );
});

self.addEventListener("push", (event) => {
  console.log("📢 Push notification received");

  const options = {
    body: "Ada cerita baru di sekitarmu! 📖",
    icon: "/po1/icons/icon-192x192.png",
    badge: "/po1/icons/icon-72x72.png",
    tag: "story-notification",
  };

  event.waitUntil(
    self.registration
      .showNotification("Cerita di Sekitarmu", options)
      .then(() => console.log("✅ Notification shown"))
      .catch((error) => console.log("⚠️ Notification failed:", error))
  );
});

self.addEventListener("notificationclick", (event) => {
  console.log("🔔 Notification clicked");
  event.notification.close();

  event.waitUntil(
    clients
      .matchAll({ type: "window" })
      .then((clientList) => {
        for (const client of clientList) {
          if (client.url.includes("/po1/") && "focus" in client) {
            return client.focus();
          }
        }
        if (clients.openWindow) {
          return clients.openWindow("/po1/");
        }
      })
      .catch((error) => console.log("⚠️ Notification click failed:", error))
  );
});

self.addEventListener("message", (event) => {
  console.log("📨 Message from app:", event.data);

  if (event.data && event.data.type === "SKIP_WAITING") {
    console.log("🔄 Skipping waiting due to app request");
    self.skipWaiting();
  }
});

self.addEventListener("error", (event) => {
  console.log("❌ SW Error:", event.error);
});

self.addEventListener("unhandledrejection", (event) => {
  console.log("❌ SW Unhandled Rejection:", event.reason);
});
